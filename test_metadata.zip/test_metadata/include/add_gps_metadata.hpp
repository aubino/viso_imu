#include <opencv2/opencv.hpp>
#include <gst/gst.h>         // GStreamer core
#include <gst/tag/tag.h>     // GStreamer tag definitions
#include <iostream>
#define GST_TAG_GPS_LATITUDE  "geo-location-latitude"
#define GST_TAG_GPS_LONGITUDE "geo-location-longitude"
#define GST_TAG_GPS_ALTITUDE  "geo-location-altitude"



bool addGpsMetadataToJpeg(const std::string& filePath, double longitude, double latitude, double altitude) {
    // gst_init(nullptr, nullptr);  // Initialize GStreamer

    // Define GStreamer pipeline to read the JPEG file (explicitly setting BGR format)
    std::string read_pipeline = "filesrc location=" + filePath + 
                                " ! jpegdec ! imagefreeze ! videoconvert ! appsink";

    // Open the video capture using GStreamer
    cv::VideoCapture cap(read_pipeline, cv::CAP_GSTREAMER);
    if (!cap.isOpened()) {
        std::cerr << "Error: Failed to open file using GStreamer: " << filePath << std::endl;
        return false;
    }

    // Read the image into cv::Mat
    cv::Mat image;
    cap.read(image);
    cap.release();  // Close the video stream

    if (image.empty()) {
        std::cerr << "Error: Failed to read image from file: " << filePath << std::endl;
        return false;
    }

    // Define GPS metadata using GStreamer tag constants
    std::string gps_metadata =
        std::string(GST_TAG_GPS_LATITUDE) + "=" + std::to_string(latitude) + "," +
        std::string(GST_TAG_GPS_LONGITUDE) + "=" + std::to_string(longitude) + "," +
        std::string(GST_TAG_GPS_ALTITUDE) + "=" + std::to_string(altitude);

    // Define the GStreamer pipeline to write the image with metadata (using BGR format)
    std::string write_pipeline =
        "appsrc ! videoconvert ! jpegenc ! "
        "taginject tags=\"" + gps_metadata + "\" ! "
        "jifmux ! filesink location=" + "/home/aubin/test_metadata/build/gps_meta.jpg";

    // Open the video writer using the GStreamer pipeline
    cv::VideoWriter writer(write_pipeline, cv::CAP_GSTREAMER, 0, 1, image.size(), true);

    if (!writer.isOpened()) {
        std::cerr << "Error: Failed to open GStreamer pipeline for writing!" << std::endl;
        return false;
    }

    // Write the image with GPS metadata
    writer.write(image);

    std::cout << "✅ Image saved successfully with GPS metadata at: " << filePath << std::endl;
    writer.release() ; 
    return true;
}

