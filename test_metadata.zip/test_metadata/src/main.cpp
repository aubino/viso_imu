#include <iostream>
#include <cstdlib>  // For std::stod
#include "add_gps_metadata.hpp"  // Include the function header

int main(int argc, char* argv[]) {
    // Ensure the correct number of arguments
    if (argc != 5) {
        std::cerr << "Usage: " << argv[0] << " <image_path> <longitude> <latitude> <altitude>" << std::endl;
        return 1;
    }

    // Parse command-line arguments
    std::string imagePath = argv[1];
    double longitude = std::stod(argv[2]);
    double latitude = std::stod(argv[3]);
    double altitude = std::stod(argv[4]);

    // Call the function to add GPS metadata
    if (!addGpsMetadataToJpeg(imagePath, longitude, latitude, altitude)) {
        std::cerr << "Failed to process the image!" << std::endl;
        return 1;
    }

    std::cout << "✅ Image successfully processed: " << imagePath << std::endl;
    return 0;
}

